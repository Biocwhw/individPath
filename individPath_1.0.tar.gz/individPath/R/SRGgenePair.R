SRGgenePair <-
function(ControlData, CaseData, PathData, cutoff){
	NumPath <- nrow(PathData);
	NumControl <- ncol(ControlData)-1;
	GeneID <- CaseData[,"geneid"];
	ReversalStat <- NULL ;
	BG.GenePairs <- NULL;
	PathGP <- matrix(0,NumPath,1);
	for( i in 1:NumPath){
		print(paste("Processing ", i, "/", NumPath," : ", PathData[i,1], sep=""));	
		tmp <- t(PathData[i,]);
		GeneList.tmp <- tmp[-c(1,2)];
		GeneList <- as.numeric(GeneList.tmp[!is.na(GeneList.tmp)]);
		InterGene <- as.matrix(intersect(GeneList, GeneID));

		if(length(InterGene)>1) {
			Genepairs <- t(combn(InterGene,2));
			Stable.tmp <- NULL;
			Reversal.tmp <- NULL;
			TmpIndex <- matrix(0,nrow(Genepairs),1);
			for (j in 1:nrow(Genepairs)) {
				fra=sum(ControlData[match(Genepairs[j,1],GeneID), -1] > ControlData[match(Genepairs[j,2],GeneID), -1])/NumControl;
				if(fra>cutoff) {
					TmpIndex[j,1]=1; 
					}
				if((1-fra)>cutoff) {
					TmpIndex[j,1]=-1; 
					}
			}
			if(sum(abs(TmpIndex))>0) {
				Genepairs <- cbind(Genepairs, TmpIndex);
			}
			if( ncol(Genepairs)>2 ) {
				Stable.tmp <- Genepairs[abs(Genepairs[ ,3])==1,];
				BG.GenePairs <- unique(rbind(BG.GenePairs,Stable.tmp));
				PathGP[i,1] <- nrow(Stable.tmp);

				
				for (k in 1:nrow(Stable.tmp)){
					loc1 <- match(Stable.tmp[k,1],GeneID);
					loc2 <- match(Stable.tmp[k,2],GeneID);				
					if (Stable.tmp[k,3]==1){
						tmp1 <- CaseData[loc1, -1] < CaseData[loc2, -1];
						Reversal.tmp <- rbind(Reversal.tmp,tmp1);					
					}	
					if (Stable.tmp[k,3]==-1){
						tmp2 <- CaseData[loc1, -1] > CaseData[loc2, -1];
						Reversal.tmp <- rbind(Reversal.tmp,tmp2);
					}	
				}			
			ReversalStat <- rbind(ReversalStat, colSums(Reversal.tmp));
			}
		}
	}
SRGgenePair.result <-list(ReversalStat,BG.GenePairs,PathGP);
names(SRGgenePair.result) <- c("ReversalStat", "BG.GenePairs" ,"PathGP");
return (SRGgenePair.result);
}
