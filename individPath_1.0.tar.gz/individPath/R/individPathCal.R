individPathCal <-
function(CaseData, StableGP, ReversalGP, NumStable, PathGP){

	GeneID <-names(CaseData);##
	individPath.result <- NULL;
	Obs.Reversal <- NULL;
	for (k in 1:NumStable){
	 loc1 <- match(StableGP[k,1],GeneID);
	 loc2 <- match(StableGP[k,2],GeneID);	
	 
		if (StableGP[k,3]==1){
			Obs.Reversal[k] <- CaseData[loc1] < CaseData[loc2];
		}
		if(StableGP[k,3]==-1){
			Obs.Reversal[k] <- CaseData[loc1] > CaseData[loc2];
		}
	}
	True.Reversal=sum(Obs.Reversal);

	individPath.result <- matrix(1,length(PathGP),1);
	for (j in 1:length(PathGP)) {
		if(ReversalGP[j]>0) {
			individPath.result[j,1]=1-phyper(ReversalGP[j]-1, True.Reversal, NumStable-True.Reversal,PathGP[j]);
		}
	}
	return(individPath.result);
}
